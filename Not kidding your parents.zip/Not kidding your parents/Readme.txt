DO NOT MODIFY THE NAME OF ANYTHING ELSE THE UNBLOCKER WILL NOT WORK!!!!!!!!!!!!!



Not kidding your parents folder---------------------------------------

NKYPV1 = Not kidding your parents version 1 

NKYPV2 = Not kidding your parents version 2

Unblocker folder------------------------------------

Unblocker1 = Unblocker for version 1 

Unblocker2 = Unblocker for version 2 


This app is used for greek parents that their kids what videos during the lesson with webex to block other apps like browsers, 
social media etc. When you run the app it look like it does nothing. But it does. From the moment that you ran the app you don't 
have access to apps that i talked before. To unblock those apps you need to run unblocker1 or unblocker2. It has to do with what
version you did ran. If you ran version 1 you need unblocker1, if you ran version 2 you need unblocker2. The files in the not 
kidding you parents folder are named with those names due to problems creating the application. You cannot unblock the apps 
that you blocked except the unblocker of your version or a special way witch i don't recomend bacause it can resault a 
"Blue Screen Of Death" known as BSoD if you stop a system proccess. Use the unblocker to make sure that it is safe. 
The unblocker has the same problem: you cannot see that it is running. Anyway, the system requirements to run this are:



                                               Intel core i2 (any i2)
                                             
                                         2 Gigs o' ram (random access memory)